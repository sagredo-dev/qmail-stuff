#!/bin/sh
set -e

echo ""
echo "You should see 7 lines of text below.  If you see anything"
echo "else, then something might be wrong."

echo "[1] Extracting qmail-1.03... "
gunzip -c qmail-1.03.tar.gz | tar xf -
cd qmail-1.03
echo "[2] Patching qmail-1.03 into netqmail-1.04.  Look for errors below:"
patch <../netqmail-1.04.patch | wc -l
echo "[4] The previous line should say 20 if you used GNU patch."
echo "[5] Renaming qmail-1.03 to netqmail-1.04..."
cd ..
mv qmail-1.03 netqmail-1.04
set +e

if [ `find ./netqmail-1.04/ -type f | grep -v '.orig$' | xargs cat | wc -c` -ne 814525 ] ; then
  echo "Patch didn't apply successfully."
  exit 1
fi
echo "[6] Continue installing qmail using the instructions found at:"
echo "[7] http://www.lifewithqmail.org/lwq.html#installation"
