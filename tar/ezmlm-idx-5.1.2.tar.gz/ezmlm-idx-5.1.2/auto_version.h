#ifndef AUTO_VERSION_H
#define AUTO_VERSION_H

extern const char auto_version[];

#endif
