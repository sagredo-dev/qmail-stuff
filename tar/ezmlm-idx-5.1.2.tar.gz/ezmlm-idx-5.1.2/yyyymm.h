#ifndef YYYYMM_H
#define YYYYMM_H

#include "stralloc.h"

extern unsigned int date2yyyymm(const char *);
extern int dateline(stralloc *, unsigned long);

#endif

