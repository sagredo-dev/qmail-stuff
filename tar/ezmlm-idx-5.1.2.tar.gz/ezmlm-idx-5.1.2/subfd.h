#ifndef SUBFD_H
#define SUBFD_H

#include "substdio.h"

extern substdio *const subfdin;
extern substdio *const subfdout;
extern substdio *const subfderr;

#endif
