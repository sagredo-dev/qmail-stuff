<?cs def:macro1() ?>This is macro1 in lincluded file<?cs /def ?>
Calling macro1 from lincluded file: <?cs call:macro1() ?>
