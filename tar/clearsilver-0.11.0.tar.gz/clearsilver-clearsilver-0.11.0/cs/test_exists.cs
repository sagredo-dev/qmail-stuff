array exists test 
<?cs var:Days[TestIf] ?>
<?cs if:?Days[TestIf] ?>
 PASS
<?cs else ?>
 ERROR
<?cs /if ?>
