This line should be shown
<?cs linclude:"test_include_recursion_failing.cs" ?>
but not this line. It should raise an error.