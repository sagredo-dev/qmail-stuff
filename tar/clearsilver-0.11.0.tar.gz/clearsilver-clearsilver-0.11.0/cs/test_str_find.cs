
<?cs var:'string.find("String1", "ring")' ?>
<?cs var:string.find("String1", "ring") ?>        

<?cs var:'string.find("String1", "1")' ?>
<?cs var:string.find("String1", "1") ?>        

<?cs var:'string.find("String1", "S")' ?>
<?cs var:string.find("String1", "S") ?>        

<?cs var:'string.find("String1", "k")' ?>
<?cs var:string.find("String1", "k") ?>        

<?cs var:'Foo = "TheString2"' ?>
<?cs set:Foo = "TheString2" ?>
<?cs var:'string.find(Foo, "Str")' ?>
<?cs var:string.find(Foo, "Str") ?>        

<?cs var:'string.find(Foo, 1+1)' ?>
<?cs var:string.find(Foo, 1+1) ?>        
