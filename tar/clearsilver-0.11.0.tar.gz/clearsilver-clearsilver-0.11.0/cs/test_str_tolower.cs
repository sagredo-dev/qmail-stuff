
<?cs var:'string.tolower("abcABC0123!#@#")' ?>
<?cs var:string.tolower("abcABC0123!#@#") ?>

<?cs var:'string.tolower("")' ?>
<?cs var:string.tolower("") ?>

<?cs var:'string.tolower(x)' ?>
<?cs var:string.tolower(x) ?>
