<?cs set:Empty[Empty] = "Oh hai!" ?>
<?cs var:Empty[Empty] ?>
<?cs var:Empty[NonExist] ?>
