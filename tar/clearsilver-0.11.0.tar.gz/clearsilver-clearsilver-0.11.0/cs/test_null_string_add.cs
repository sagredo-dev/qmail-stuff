<?cs set:Really.Large.hide = Really.Large.hide + Really.Long['foo'] ?>
