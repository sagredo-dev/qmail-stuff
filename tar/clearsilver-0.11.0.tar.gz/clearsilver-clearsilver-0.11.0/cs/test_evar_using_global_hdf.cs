evar and lvar should work the same for elements in global hdf
that exist at parse time.

lvar: <?cs lvar:GlobalTree.expr ?>
evar: <?cs evar:GlobalTree.expr ?>
