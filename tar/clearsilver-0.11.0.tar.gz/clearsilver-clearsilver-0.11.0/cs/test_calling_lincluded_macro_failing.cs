<?cs linclude:"test_lincluded_macro.cs" ?>
Nothing should print as that next line fails at parsing.
Calling macro1 from main: <?cs call:macro1() ?>
