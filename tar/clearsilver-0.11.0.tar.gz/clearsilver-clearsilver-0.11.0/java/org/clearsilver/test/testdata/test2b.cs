Testing CS render time include file...

PreInclude
<?cs linclude:'testdata/test2include.cs' ?>
PostInclude
