Testing CS parse time include file...

PreInclude
<?cs include:'testdata/test2include.cs' ?>
PostInclude
