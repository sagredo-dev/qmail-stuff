/*
 * $Id: forward.h,v 1.1.2.1 2004/11/20 01:10:41 tomcollins Exp $
 */
 
int show_forwards(char *user, char *dom, time_t mytime);
void count_forwards();
