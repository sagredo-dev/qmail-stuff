/*
 * $Id: command.h,v 1.1.2.1 2004/11/20 01:10:41 tomcollins Exp $
 */

void process_commands();
void setdefaultaccount();
