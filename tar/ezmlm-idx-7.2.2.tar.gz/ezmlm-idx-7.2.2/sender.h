#ifndef SENDER_H
#define SENDER_H

extern const char *get_sender(void);

#endif
