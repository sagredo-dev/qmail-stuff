#ifndef FORK_H
#define FORK_H

#include <sys/types.h>
extern pid_t fork();

#endif
