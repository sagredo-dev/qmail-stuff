#ifndef AUTO_BIN_H
#define AUTO_BIN_H

extern const char *auto_bin(void);

#endif
