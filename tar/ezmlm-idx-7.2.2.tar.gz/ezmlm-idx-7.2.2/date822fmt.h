#ifndef DATE822FMT_H
#define DATE822FMT_H

struct datetime;
extern unsigned int date822fmt(char *, const struct datetime *);
#define DATE822FMT 60

#endif
