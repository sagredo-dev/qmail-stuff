/* Public domain, from djbdns-1.05. */
/* As per http://cr.yp.to/djbdns/res-disaster.html */

#ifndef EXIT_H
#define EXIT_H

extern void _exit(int);

#endif
