/*
   Define some general database error conditions
*/

#define DB_E_SUCCESS      1 /* Last operation was successful				    */
#define DB_E_NONE         0 /* No database present; returned only by db_open()              */
#define DB_E_CREDENTIALS -1 /* Missing required credentials to connect to a database server */
#define DB_E_CONNECT     -2 /* Database connection function returned error                  */
#define DB_E_DATABASE    -3 /* Database specified does not exist, or is inaccessable        */
#define DB_E_MEM         -4 /* Out of memory during database function call                  */
#define DB_E_QUERY       -5 /* Database query failed                                        */
