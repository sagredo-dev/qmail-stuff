#include <stdio.h>
#include "global.h"
#include "db_misc.h"
#include "db.h"

/*
   All functions here return error codes.
   vol@inter7.com
*/

int db_open(void)
{
  return DB_E_NONE;
}

void db_close(void)
{
}

int db_insert_data(char *table, char **nfields, char **fields)
{
  return DB_E_NONE;
}
