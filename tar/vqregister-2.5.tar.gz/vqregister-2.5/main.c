#include <stdio.h>
#include "global.h"

int main(int argc, char *argv[])
{
  global_init(); 

  if (argc > 1)
     config_open(argv[1]);
  else
     config_open("vqregister.conf");

  cgi_init();
  cgi_nav();

  return 0;
}
