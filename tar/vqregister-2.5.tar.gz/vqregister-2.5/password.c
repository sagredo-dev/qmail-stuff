#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include "global.h"

static char gen_chars[] = "abcdefghijklmnopqrstuvwxyz" \
                          "ABCDEFGHIJKLMNOPQRSTUVWXYZ" \
                          "0123456789.@!#%*";

char *gen_pass(char len)
{
  char gen_char_len = 0, i = 0, k = 0, *p = NULL;

  gen_char_len = strlen(gen_chars);

  p = (char *)malloc(len + 1);
  if (p == NULL)
     return NULL;

  srand(rand() % time(NULL) ^ getpid());

  memset((char *)p, len, 0);

  for (i = 0; i < len; i++) {
      k = rand()%gen_char_len;

      p[i] = gen_chars[k];
  }

  return p;
}
