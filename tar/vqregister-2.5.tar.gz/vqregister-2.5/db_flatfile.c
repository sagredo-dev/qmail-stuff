/*
   Routines to store demographic information in flatfile format.
   vol@inter7.com
*/

#include <stdio.h>
#include "global.h"
#include "db_misc.h"
#include "db.h"

FILE *gstream = NULL;

int db_open(void)
{
  gstream = fopen(FLATFILE, "a");
  if (gstream == NULL)
     return DB_E_CONNECT;

  return DB_E_SUCCESS;
}

void db_close(void)
{
  fclose(gstream);
}

int db_insert_data(char *table, char **nfields, char **fields)
{
  int i = 0;

  for (i = 0; nfields[i]; i++)
      fprintf(gstream, "%s ", fields[i]);

  fprintf(gstream, "\n");

  return DB_E_SUCCESS;
}
