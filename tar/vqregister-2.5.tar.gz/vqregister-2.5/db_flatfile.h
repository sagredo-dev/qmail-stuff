/*
   vol@inter7.com
*/

#define FLATFILE "user.data"
