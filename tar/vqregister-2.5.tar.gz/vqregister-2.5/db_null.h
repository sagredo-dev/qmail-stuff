/*
   Blank database header.
   vol@inter7.com
*/
