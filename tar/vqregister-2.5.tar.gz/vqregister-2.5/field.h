/*
   Field list definition
*/

struct field_t {
  char *tname,
       **fields;

  struct field_t *next;
};
