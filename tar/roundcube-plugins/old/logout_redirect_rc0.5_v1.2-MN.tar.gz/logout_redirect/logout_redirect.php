<?php/**
 * Redirect on logout
 *
 * @version 1.2 - 04.05.2011
 * @author Roland 'rosali' Liebl
 * @website http://myroundcube.googlecode.com
 * @licence GNU GPL
 * @history 1.1 - 26.12.2010
 * @        1.2 - 04.05.2011 - set default return when still %d in return link
 *
 **/
/**
 * Notice: This plugin must run as the last plugins because it exits
  *         on the 'logout_after' hook !!!
**/
/**
 * stripped down to an only logout function with variable return page
 * rewritten by Markus Neubauer
 **/
 
/**
 *
 * Usage: http://www.std-soft.com/bfaq/52-cat-webmail/105-logout-redirect-fuer-roundcube.html
 *
 **/ 
 
class logout_redirect extends rcube_plugin
{
  public $task = 'logout';
  
  function init()
  {
    if(file_exists("./plugins/logout_redirect/config/config.inc.php"))
      $this->load_config('config/config.inc.php');
    else
      $this->load_config('config/config.inc.php.dist');

    $this->add_hook('logout_after', array($this,'logout_after'));
  }
  
  // user logout 
  function logout_after($args)  
  {        
    $rcmail = rcmail::get_instance();

    if( $rcmail->config->get('logout_redirect_url') ) {

        $redirect = $rcmail->config->get('logout_redirect_url');

        if ( preg_match('/%d/',$redirect) ) {
          $sql_result = $rcmail->db->query("SELECT t2.email FROM ".$rcmail->config->get('db_table_users')." as t1 join ".$rcmail->config->get('db_table_identities')." as t2 on t1.user_id = t2.user_id where t1.username=? and t2.standard=1", $args['user']);
          if ($sql_result && ($sql_arr = $rcmail->db->fetch_assoc($sql_result))) {
            list($name,$domain) = explode('@', $sql_arr['email']);
            $redirect = str_replace('%d', $domain, $redirect);
          }
        }
        if ( !preg_match('/%d/',$redirect) ) {
          setcookie ('ajax_login','',time()-3600);
          $rcmail->output->add_script('top.location.href="' . $redirect . '";');
          $rcmail->output->send('plugin'); 
          exit; 
        }
    }

    return $args; 
  } 
     
}
?>