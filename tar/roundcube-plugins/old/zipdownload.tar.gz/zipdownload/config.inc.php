<?php

/**
 * ZipDownload configuration file
 */

// Zip attachments
// Only show the link when there are more than this many attachments
// -1 to prevent downloading of attachments as zip
$rcmail_config['zipdownload_attachments'] = 1;

// Zip entire folders
$rcmail_config['zipdownload_folder'] = false;

// Zip selection of messages
$rcmail_config['zipdownload_selection'] = false;

// Charset to use for filenames inside the zip
$rcmail_config['zipdownload_charset'] = 'ISO-8859-1';

?>