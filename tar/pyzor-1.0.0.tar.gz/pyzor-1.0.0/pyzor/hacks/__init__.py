"""Various hack to make pyzor compatible with different Python versions."""
