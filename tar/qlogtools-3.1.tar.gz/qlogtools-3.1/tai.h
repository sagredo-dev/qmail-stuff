#ifndef QLOGTOOLS__TAI__H__
#define QLOGTOOLS__TAI__H__

#include "bool.h"

struct tai
{
  unsigned long seconds;
  unsigned long nanoseconds;
};
typedef struct tai tai;

tai* tai64n_decode(const char* str, const char** endptr);
bool tai64n_encode(const tai* t, char* buf);

tai* tai_decode(const char* str, const char** endptr);
bool tai_encode(const tai* t, char* buf);

#endif
