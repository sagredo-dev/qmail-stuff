#ifndef SVC_FNS__H__
#define SVC_FNS__H__

#define FD_STDIN 0
#define FD_STDOUT 1
#define FD_STDERR 2

#include <sys/types.h>
void exec_supervise(const char* dir, int fdin, int fdout);
pid_t start_supervise(const char* dir, int fdin, int fdout);
int stop_supervise(const char* dir, pid_t svcpid);

/* Required external functions */
extern void err(const char* msg);

#endif
