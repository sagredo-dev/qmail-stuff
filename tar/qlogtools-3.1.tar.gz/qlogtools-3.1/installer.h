#ifndef SPAC__INSTALLER__H__
#define SPAC__INSTALLER__H__

int opendir(const char* dir);
int opensubdir(int dir, const char* subdir);
void d(int dir, const char* subdir,
       unsigned uid, unsigned gid, unsigned mode);
void c(int dir, const char* subdir, const char* file,
       unsigned uid, unsigned gid, unsigned mode);

extern void insthier(void);

#endif
