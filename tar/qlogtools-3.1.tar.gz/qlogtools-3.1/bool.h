#ifndef QLOGTOOLS__BOOL__H__
#define QLOGTOOLS__BOOL__H__

typedef int bool;
#define false 0
#define true (0==0)

#endif
