#include "installer.h"
#include "conf_bin.c"
#include "conf_man.c"

void insthier(void) {
  int bin = opendir(conf_bin);
  int man = opendir(conf_man);
  int man1;
  
  c(bin, 0, "multipipe",       -1, -1, 0755);
  c(bin, 0, "multitail",       -1, -1, 0755);
  c(bin, 0, "qfilelog",        -1, -1, 0755);
  c(bin, 0, "spipe",           -1, -1, 0755);
  c(bin, 0, "tai2tai64n",      -1, -1, 0755);
  c(bin, 0, "tai64n2tai",      -1, -1, 0755);
  c(bin, 0, "teepipe",         -1, -1, 0755);

  d(man, "man1", -1, -1, 0755);
  man1 = opensubdir(man, "man1");
  c(man1, 0, "multipipe.1",  -1, -1, 0644);
  c(man1, 0, "multitail.1",  -1, -1, 0644);
  c(man1, 0, "qfilelog.1",   -1, -1, 0644);
  c(man1, 0, "spipe.1",      -1, -1, 0644);
  c(man1, 0, "tai2tai64n.1", -1, -1, 0644);
  c(man1, 0, "tai64n2tai.1", -1, -1, 0644);
  c(man1, 0, "teepipe.1",    -1, -1, 0644);
}
