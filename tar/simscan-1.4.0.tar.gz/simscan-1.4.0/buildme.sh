./configure --disable-ripmime --enable-custom-smtp-reject --enable-dspam --enable-per-domain --enable-spam-passthru --enable-dspam-path=/home/vpopmail/dspam/bin/dspam
