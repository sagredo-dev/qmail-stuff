print('hello')
import os
print os.getuid(), os.geteuid()
