/*$Id: opensub.c 380 2005-07-12 22:33:57Z bruce $*/

#include "str.h"
#include "slurp.h"
#include "stralloc.h"
#include "strerr.h"
#include "errtxt.h"
#include "subscribe.h"
#include <unistd.h>
#include <libpq-fe.h> 

PGconn *pgsql = 0;

const char *opensub(const char *dir,	/* database directory */
		    const char *subdir,
		    const char **table)	/* table root_name */
{
  struct sqlinfo info;
  const char *err;
  
  if ((err = parsesql(dir,subdir,&info)) != 0)
    return err;
  *table = info.table;

  if (!pgsql) {
    /* Make connection to database */
    pgsql = PQsetdbLogin(info.host,info.port,NULL,NULL,
			 info.db,info.user,info.pw);
    /* Check  to see that the backend connection was successfully made */
    if (PQstatus(pgsql) == CONNECTION_BAD)
      return PQerrorMessage(pgsql);
  }
  return (char *) 0;
}

void closesub(void)
/* close connection to SQL server, if open */
{
  if (pgsql)
    PQfinish(pgsql);
  pgsql = 0;		/* Destroy pointer */
  return;
}
