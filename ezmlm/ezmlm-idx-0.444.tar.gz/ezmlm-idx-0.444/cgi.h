/*$Id: cgi.h 367 2005-07-11 22:21:48Z bruce $*/
#ifndef CGI_H
#define CGI_H

#include "hasattribute.h"

extern void cgierr(const char *,const char *,const char *) __attribute((noreturn));

#endif
