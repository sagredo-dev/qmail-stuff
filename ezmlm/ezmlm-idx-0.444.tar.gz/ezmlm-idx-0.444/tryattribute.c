void foo() __attribute__((noreturn));
