#ifndef AUTO_QMAIL_H
#define AUTO_QMAIL_H

extern const char auto_qmail[];

#endif
