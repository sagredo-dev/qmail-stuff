#ifndef LOG_H
#define LOG_H

extern void logaddr(const char *dir,const char *subdir,const char *event,
		    const char *addr,const char *comment);

#endif
