/* Public domain, from daemontools-0.76. */

#ifndef FD_H
#define FD_H

extern int fd_copy(int,int);
extern int fd_move(int,int);

#endif
